<style type="text/css">
#wp-easycart{
	background-color: rgb(209, 231, 212);
}

#wp-easycart .plugin-title{
	 
}

#wp-easycart .plugin-description p{
	font-family:Arial, Helvetica, sans-serif;
	background-repeat: no-repeat;	
	font-size:12px;
}

#wp-easycart .second {
	padding:0;
}

#wp-easycart .plugin-version-author-uri{
	background-color: #e3fde7;
	padding-left: 5px;
	height: 20px;
	line-height: 20px;
	margin-bottom: 5px;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #030;
}

#wp-easycart .plugin-version-author-uri a{
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-weight: bold;
	color: #030;
}

#wp-easycart .plugin-version-author-uri a:hover{
	color: #060;
}
</style>