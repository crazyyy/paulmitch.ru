<div class="ec_popup_background" id="ec_popup_background"></div>
<div class="ec_popup" id="ec_popup">
    <div class="ec_popup_title">
        <div class="ec_popup_title_inner">
            <span id="ec_popup_title"></span><a href="#" onclick="ec_hide_alert_box( ); return false;" class="ec_popup_close_button">CLOSE</a>
        </div>
    </div>
    <div class="ec_popup_content">
        <div class="ec_popup_content_inner">
            <span id="ec_popup_content"></span>
        </div>
    </div>
</div>