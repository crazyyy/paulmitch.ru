<div class="ec_admin_leftmenu">
    <div class="ec_admin_leftmenu_inner arrow_pos_1">
        <div class="ec_admin_leftmenu_header">EasyCart Dashboard</div>
        <div class="ec_admin_leftmenu_item_selected">Statistics</div>
        <div class="ec_admin_leftmenu_item">Store Status</div>
        <div class="ec_admin_leftmenu_item">Backup Store</div>
    </div>
</div>