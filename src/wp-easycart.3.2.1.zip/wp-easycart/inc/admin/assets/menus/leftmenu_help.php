<div class="ec_admin_leftmenu">
    <div class="ec_admin_leftmenu_inner arrow_pos_1">
        <div class="ec_admin_leftmenu_header">Help and Support</div>
        <div class="ec_admin_leftmenu_item<?php if( isset( $_GET['ec_panel'] ) && $_GET['ec_panel'] == "support" ){ echo "_selected"; } ?>"><a href="admin.php?page=ec_adminv2&ec_page=dashboard&ec_panel=backup-store">Help and Support</a></div>
    </div>
</div>