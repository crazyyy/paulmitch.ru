;
ALTER TABLE ec_optionitem ADD `optionitem_price_per_character` FLOAT(15,3) NOT NULL DEFAULT 0.000 COMMENT 'When using text field or textbox input, you can add price per character.';