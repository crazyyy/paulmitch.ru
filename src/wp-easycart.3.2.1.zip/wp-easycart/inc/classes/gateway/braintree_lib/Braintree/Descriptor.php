<?php
class Braintree_Descriptor extends Braintree_Instance
{
}
